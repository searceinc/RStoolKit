import os
import boto3
import psycopg2
import sys
import csv
import smtplib  
import email.utils
from base64 import b64decode
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase

# Get the date
t_date=datetime.now().strftime("%Y"'-'"%m"'-'"%d")

# Get values from Env
REDSHIFT_DATABASE = os.environ['REDSHIFT_DATABASE']
REDSHIFT_USER     = os.environ['REDSHIFT_USER']
REDSHIFT_PASSWD   = os.environ['REDSHIFT_PASSWD']
REDSHIFT_PORT     = os.environ['REDSHIFT_PORT']
REDSHIFT_ENDPOINT = os.environ['REDSHIFT_ENDPOINT']
SES_USERNAME      = os.environ['SES_USERNAME']
SES_PASSWORD      = os.environ['SES_PASSWORD']
SES_ENDPOINT      = os.environ['SES_ENDPOINT']
SES_SENDER_EMAIL  = os.environ['SES_SENDER_EMAIL']
SES_RECIPIENT     = os.environ['SES_RECIPIENT']

# RedShift connection function
def get_pg_con(
    user=REDSHIFT_USER,
    password=REDSHIFT_PASSWD,
    host=REDSHIFT_ENDPOINT,
    dbname=REDSHIFT_DATABASE,
    port=REDSHIFT_PORT,
    ):
    return psycopg2.connect(dbname=dbname, 
      host=host, 
      user=user,
      password=password,
      port=port)

# Main function
def lambda_handler(event, context):   
    health_query=open('health-check.sql', 'r').read()
    conn = get_pg_con()
    cur = conn.cursor()
    cur.execute(health_query)
    cur.execute("""SELECT CASE 
         WHEN priority = 0 THEN 0
         WHEN priority = 1 THEN 10 
         WHEN priority = 2 THEN 50 
         WHEN priority = 3 THEN 200 
         ELSE 1000 
       END AS priority, 
       category, 
       finding, 
       details, 
       url 
       FROM   rstk_metric_result 
       ORDER  BY priority;""")
    
    # Write the output
    with open('/tmp/result.csv', 'w') as f:
        writer = csv.writer(f, delimiter=',')
        for row in cur.fetchall():
            writer.writerow(row)
    conn.commit()
    cur.close()
    conn.close()
    
    # Add the headers
    os.system("sed -i '1 i\priority,category,finding,details,url' /tmp/result.csv")
    
    # Get the email template
    with open('email-template.html', 'r') as f:
        EMAIL_BODY=f.read()
    
    #SMTP - SES Details
    SENDER = SES_SENDER_EMAIL  
    SENDERNAME = 'RStoolKit'
    RECIPIENT  = SES_RECIPIENT
    USERNAME_SMTP = SES_USERNAME
    PASSWORD_SMTP = SES_PASSWORD
    HOST = SES_ENDPOINT
    PORT = 587
    
    # Mail content
    SUBJECT = t_date+' | RStoolKit - Report'
    #BODY_TEXT = ("Amazon SES Test\r\n"
    #             "This email was sent through the Amazon SES SMTP "
    #             "Interface using the Python smtplib package."
     #           )
    BODY_HTML = EMAIL_BODY
    
    msg = MIMEMultipart('alternative')
    msg['Subject'] = SUBJECT
    msg['From'] = email.utils.formataddr((SENDERNAME, SENDER))
    msg['To'] = RECIPIENT
    RECIPIENT_LIST = RECIPIENT.split(',')
    print (RECIPIENT_LIST)
    #test = RECIPIENT.split(",")
    #print(test)
    #print('============')
    #part1 = MIMEText(BODY_TEXT, 'plain')
    part2 = MIMEText(BODY_HTML, 'html')
    #msg.attach(part1)
    msg.attach(part2)
    mail_file = MIMEBase('application', 'csv')
    mail_file.set_payload(open('/tmp/result.csv', 'rb').read())
    mail_file.add_header('Content-Disposition', 'attachment', filename='rstool-health-report.csv')
    msg.attach(mail_file)
    try:  
        server = smtplib.SMTP(HOST, PORT)
        server.ehlo()
        server.starttls()
        #stmplib docs recommend calling ehlo() before & after starttls()
        server.ehlo()
        server.login(USERNAME_SMTP, PASSWORD_SMTP)
        server.sendmail(SENDER, RECIPIENT_LIST, msg.as_string())
        server.close()
    # Display an error message if something goes wrong.
    except Exception as e:
        print ("Error: ", e)
    else:
        print ("Email sent!")
